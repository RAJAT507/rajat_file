import React from "react";
import ImageUpload from "./ADMIN/UploadImage";

const Home = () => {
  return (
    <div>
      Home
      <ImageUpload />
    </div>
  );
};

export default Home;
